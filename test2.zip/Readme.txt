Thanks for downloading the Cubix resource pack!
Cubix By antti662 @curse.com
-----------
How to install:
1.Download the Cubix resource pack
2.Run Minecraft
3.Click "Resource Packs"
4.Click "Open Res.Pack folder"
5.Put the Cubix.zip in there
6.Select it and play!

-----------
You are not allowed to use my textures without my permission.
You are allowed to make videos with my resource pack. You don`t need to ask my permission, but It`d be cool if you notify me about that.
-----------
